using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

public class PlayerJumpState : PlayerBaseState
{
    public PlayerJumpState(PlayerController currentContext, StateFactory stateFactory) : base(currentContext, stateFactory)
    {
        InitializeSubstates();
        _isRootState = true;
    }


    public override void EnterState()
    {
      
    }


    public override void ExitState()
    {
        ResetJump();
    }


    public override void InitializeSubstates()
    {
        if (_ctx._isMoving)
        {
            SetSubState(_stateFactory.Move());
        }
        else if (!_ctx._isMoving)
        {
            SetSubState(_stateFactory.Idle());
        }
    }


    public override void UpdateState()
    {
        CheckSwitchState();
        Debug.Log("Jump State");
    }


    public override void FixedUpdateState()
    {
        Jump();
    }


    public override void CheckSwitchState()
    {
        if(!_ctx.OnGround())
        {
            SwitchState(_stateFactory.Grounded());
        }
    }
  

    private void Jump()
    {
        if (!_ctx._addingCounterJump)
        {
            //_ctx._playerrb.AddForce(new Vector3(0,_ctx._moveDir.y * Mathf.Sqrt(2f * _ctx._gravity * _ctx._playerJumpHeight*10000000), 0) * Time.deltaTime, ForceMode.Impulse); // jump
            //playerAnim.SetTrigger("Jump");
            //_ctx._playerrb.AddForce(_ctx._moveDir * Mathf.Sqrt(2f * _ctx._gravity * _ctx._playerJumpHeight) * Time.deltaTime, ForceMode.Impulse);//dash
            _ctx._playerrb.AddForce(_ctx.transform.up * Mathf.Sqrt(2f * _ctx._gravity * _ctx._playerJumpHeight) * Time.deltaTime, ForceMode.Impulse); // jump
            _ctx._addingCounterJump = true;
            _ctx._jumpReset = true;
        }
    }


    private async void ResetJump()
    {
        await Task.Delay(1000); // mili sec 1000s^-3 = 1sec
        _ctx._jumpReset = false;
    }
}
