using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StateFactory 
{
    PlayerController _context;
    public StateFactory(PlayerController currentContext)
    {
        _context = currentContext;
    }
    public PlayerBaseState Grounded()
    {
        return new PlayerGroundedState(_context, this);
    }
    public PlayerJumpState Jump()
    {
        return new PlayerJumpState(_context, this);
    }
    public PlayerMoveState Move()
    {
        return new PlayerMoveState(_context, this);
    }
    public PlayerIdleState Idle()
    {
        return new PlayerIdleState(_context, this);
    }
}
