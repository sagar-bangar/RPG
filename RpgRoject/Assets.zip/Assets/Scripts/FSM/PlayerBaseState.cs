public abstract class PlayerBaseState 
{
    protected bool _isRootState=false;
    protected PlayerController _ctx;
    protected StateFactory _stateFactory;
    protected PlayerBaseState _currentSuperState;
    protected PlayerBaseState _currentSubState;
    public PlayerBaseState(PlayerController currentContext,StateFactory stateFactory)
    {
        _ctx = currentContext;
        _stateFactory = stateFactory;
    }
    public abstract void EnterState();

    public abstract void ExitState();

    public abstract void UpdateState();

    public abstract void FixedUpdateState();

    public abstract void CheckSwitchState();

    public abstract void InitializeSubstates();


   public void UpdateStates()
    {
        UpdateState();
        if(_currentSubState!=null)
        {
            _currentSubState.UpdateStates();
        }
    }
    public void FixedUpdates()
    {
        FixedUpdateState();
        if (_currentSubState != null)
        {
            _currentSubState.FixedUpdates();
        }
    }


    protected void SwitchState(PlayerBaseState newState)
    {
        ExitState();
        newState.EnterState();
        if(_isRootState)
        {
            _ctx._currentState = newState;
        }
        else if(_currentSuperState!=null)
        {
            _currentSuperState.SetSubState(newState);
        }
    }
    

    protected void SetSuperState(PlayerBaseState newSuperState)
    {
        _currentSuperState = newSuperState;
    }


    protected void SetSubState(PlayerBaseState newSubState)
    {
        _currentSubState = newSubState;
        newSubState.SetSuperState(this);
    }
}
