using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerGroundedState : PlayerBaseState
{
    public PlayerGroundedState(PlayerController currentContext,StateFactory stateFactory) : base(currentContext, stateFactory) 
    {
        InitializeSubstates();
        _isRootState = true;
    }


    public override void EnterState()
    {

    }


    public override void ExitState()
    {
        
    }

    public override void InitializeSubstates()
    {
        if (_ctx._isMoving)
        {
            SetSubState(_stateFactory.Move());
        }
        else if (!_ctx._isMoving)
        {
            SetSubState(_stateFactory.Idle());
        }
    }


    public override void UpdateState()
    {
        CheckSwitchState();
        Debug.Log("Grounded State");
    }


    public override void FixedUpdateState()
    {
        ApplyGravity();
    }

    public override void CheckSwitchState()
    {
        if(Input.GetKeyDown(KeyCode.Space) && !_ctx._jumpReset &&  _ctx.OnGround())
        {
            SwitchState(_stateFactory.Jump());
        }
    }


    private void ApplyGravity()
    {
        if(!_ctx.OnGround())
        {
            if (_ctx._playerrb.velocity.y>0)//while jumping
            {
                _ctx._playerrb.AddForce(-_ctx.transform.up * (_ctx._gravity * _ctx._jumpMultiplier) * Time.deltaTime, ForceMode.Acceleration); // apply while jumping Gravity (jumpmultiplier=0-1)
            }
            else if(_ctx._playerrb.velocity.y < 0 && !Input.GetKeyDown(KeyCode.Space))//while falling
            {
                _ctx._playerrb.AddForce(-_ctx.transform.up * (_ctx._gravity * _ctx._fallMultiplier) * Time.deltaTime, ForceMode.Acceleration); // apply while falling Gravity (fallmultipier=1-2)
            }
            else if(_ctx._playerrb.velocity.y==0)
            {
                _ctx._playerrb.AddForce(-_ctx.transform.up * _ctx._gravity * Time.deltaTime, ForceMode.Acceleration); // apply while on ground Gravity
            }

        }
           
        else
        {
            if (_ctx._addingCounterJump) // prevent from sliding
            {
                _ctx._playerrb.velocity = Vector3.zero;
                _ctx._addingCounterJump = false;
            }
        }
    }


}
