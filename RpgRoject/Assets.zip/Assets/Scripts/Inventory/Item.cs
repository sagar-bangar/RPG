using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    //Reference
    public Sprite itemSprite;
    public string itemName;
}
